<?php

return [
    'Report'        => 'Мероприятие',
    'Preview'       => 'Анонс',
];
