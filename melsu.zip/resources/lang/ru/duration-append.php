<?php

return [
    'year-one'      => ' год',
    'year-some'     => ' года',
    'year-many'     => ' лет',
    'month-one'     => ' месяц',
    'month-some'    => ' месяца',
    'month-many'    => ' месяцев',
    'after_9'       => ' После 9 классов:',
    'after_11'      => ' После 11 классов:',
    'short-year'    => 'г.',
    'short-month'   => 'м.',
];
