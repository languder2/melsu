<?php

return [
    'Divisions'             => 'Подразделения',
    'New'                   => 'Форма добавления',

    'type.rectorate'        => 'Ректорат',
    'type.division'         => 'Департамент',
    'type.administration'   => 'Управление',
    'type.office'           => 'Отдел',

    'type.representative'   => 'Представительство',
    'type.branch'           => 'Филиал',

    'type.institute'        => 'Институт',
    'type.faculty'          => 'Факультет',
    'type.department'       => 'Кафедра',
    'type.lab'              => 'Лаборатория',

    'type.other'            => 'Иное',
];
