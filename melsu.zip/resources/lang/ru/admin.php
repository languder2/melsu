<?php

return [
    'Admin panel'       => 'Админ панель',
    'Admin panel: '     => 'Админ панель → ',
    'Edit'              => 'Редактировать',
    'Create'            => 'Создать',
];
