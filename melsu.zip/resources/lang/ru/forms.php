<?php

return [
    'is_show'           => 'Выводится',
    'is_hide'           => 'Скрыто',
    'show'              => 'Вывести',
    'hide'              => 'Скрыть',
];
