<?php

return [
    'style.alignment.left' => 'text-left',
    'style.alignment.right' => 'text-right',
    'style.alignment.center' => 'text-center',
    'style.alignment.justify' => 'text-justify',

    'style.bg-info' => 'p-4 bg-white'
];
