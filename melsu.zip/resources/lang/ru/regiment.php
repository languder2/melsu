<?php

return [
    'Regiments'                         => 'Полки',

    'Immortal and Scientific'           => 'Бессмертный и Научный',
    'Immortal'                          => 'Бессмертный',
    'Scientific'                        => 'Научный',
    'SVO'                               => 'Герои среди нас',

    'Immortal and Scientific Regiment'  => 'Бессмертный и Научный полки',
    'Immortal Regiment'                 => 'Бессмертный полк',
    'Scientific Regiment'               => 'Научный полк',
    'SVO Full'                          => 'Герои среди нас',
];
