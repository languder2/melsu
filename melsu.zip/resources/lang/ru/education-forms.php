<?php

return [
    "short.full-time"           => 'Очная',
    "short.full-part"           => 'Очно-заочная',
    "short.correspondence"      => 'Заочная',

    "full-time"           => 'Очная форма',
    "full-part"           => 'Очно-заочная форма',
    "correspondence"      => 'Заочная форма',
];
