<?php

return [
    's:App\Models\Projects\Cluster' => "Кластер",
    'm:App\Models\Projects\Cluster' => "Кластеры",

    'cluster'           => "Кластеры",
    'singular-cluster'  => "Кластер",
];
