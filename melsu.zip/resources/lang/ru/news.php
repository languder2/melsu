<?php

return [
    'New news'          => 'Новая новость',
    'News categories'   => 'Категории новостей',
    'Delete category question'  => 'Удалить категорию новостей?',
    'Edit news categories'      => 'Редактировать категорию новостей',
    'Create news categories'    => 'Создать категорию новостей',
];
