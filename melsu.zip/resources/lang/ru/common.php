<?php

return [
    'Cabinet'       => 'Кабинет',
    'Divisions'     => 'Подразделения',
    'New'           => 'Форма добавления',

    'arrowR'        => ' → ',
    'arrowL'        => ' ← ',
    'arrowT'        => ' ↑ ',
    'arrowD'        => ' ↓ ',
    'arrowT2R'      => ' ⤷ ',

    'melsu'         => 'ФГБОУ ВО "МелГУ"',

    'office'        => 'Кабинет',

];
