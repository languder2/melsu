<?php

return [
    'Budget'        => 'Бюджет',
    'Contract'      => 'Контракт',
];
