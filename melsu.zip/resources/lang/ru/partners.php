<?php

return [
    'Partners'                      => 'Партнеры',
];
