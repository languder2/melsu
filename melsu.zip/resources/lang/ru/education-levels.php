<?php

return [
    'Bachelor'          => 'Бакалавриат',
    'Specialist'        => 'Специалитет',
    'Master'            => 'Магистратура',
    'Colleges'          => 'Колледжи',
    'Postgraduate'      => 'Аспирантура',

    'BachelorAlt'       => 'Бакалавр',
    'SpecialistAlt'     => 'Специалист',
    'MasterAlt'         => 'Магистр',
    'CollegesAlt'       => 'СПО',
    'PostgraduateAlt'   => 'Аспирантура',
];
