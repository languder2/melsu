<?php

return [
    'title'             => 'Заголовок (title)',
    'keywords'          => 'Ключевые слова (keywords)',
    'description'       => 'Описание (description)',
];
