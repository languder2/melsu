<svg width="{{ $width ?? 34}}" height="{{ $height ?? 34 }}" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg"
    class="rotate-45"
>
    <path d="M2 17H17M32 17H17M17 17V32M17 17V2" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
</svg>
