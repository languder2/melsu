<div class="main-content p-5 pt-[1.375rem] bg-white mb-3">
    <h3 class="text-xl border-b mb-2 pb-2 font-semibold">
        {{$department->name}}
    </h3>
    <div>
        {{$faculty->description}}
        <p class="mb-4">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam aut beatae dolores, doloribus ducimus
            earum eveniet laudantium magnam numquam odio perspiciatis placeat porro praesentium, quas tempore veniam
            vero. Eveniet, explicabo? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur cumque enim
            incidunt, laborum minima odio perferendis quia quis tempora veniam. Alias autem blanditiis dolor et nam
            optio quidem quo voluptas?
        </p>
        <p class="mb-4">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam aut beatae dolores, doloribus ducimus
            earum eveniet laudantium magnam numquam odio perspiciatis placeat porro praesentium, quas tempore veniam
            vero. Eveniet, explicabo? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur cumque enim
            incidunt, laborum minima odio perferendis quia quis tempora veniam. Alias autem blanditiis dolor et nam
            optio quidem quo voluptas?
        </p>
        <p class="mb-4">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam aut beatae dolores, doloribus ducimus
            earum eveniet laudantium magnam numquam odio perspiciatis placeat porro praesentium, quas tempore veniam
            vero. Eveniet, explicabo? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur cumque enim
            incidunt, laborum minima odio perferendis quia quis tempora veniam. Alias autem blanditiis dolor et nam
            optio quidem quo voluptas?
        </p>
        <p class="mb-4">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam aut beatae dolores, doloribus ducimus
            earum eveniet laudantium magnam numquam odio perspiciatis placeat porro praesentium, quas tempore veniam
            vero. Eveniet, explicabo? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur cumque enim
            incidunt, laborum minima odio perferendis quia quis tempora veniam. Alias autem blanditiis dolor et nam
            optio quidem quo voluptas?
        </p>
    </div>

</div>
