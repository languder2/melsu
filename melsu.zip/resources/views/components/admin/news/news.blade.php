<x-admin.news.header/>

<x-admin.news.list :list="$list??[]"/>

{{@$list->links()}}
