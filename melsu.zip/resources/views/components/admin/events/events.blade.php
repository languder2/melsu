<x-admin.events.header/>

<x-admin.events.list :list="$list??[]"/>
