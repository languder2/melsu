<div class="pb-2 ps-2 mb-4 flex border-b">
    <h2 class="flex-1 text-2xl font-semibold">
        Добавление специальности
    </h2>
    <div>
        <x-form.button
            class="uppercase"
            value="сохранить"
        />
    </div>
</div>
