<div
    @class([
        'flex',
        'gap-2'
    ])
>
    {{$slot}}
</div>
