<div class="mx-auto">
    {!! clean_svg($slot->toHTML()) !!}
</div>
