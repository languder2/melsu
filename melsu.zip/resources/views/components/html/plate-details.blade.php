<div
    class="
        absolute bottom-0 right-0 z-50
        bg-base-red text-white
        w-0
        overflow-hidden
        transition-all duration-300
        group-hover:w-40
    "
>
    <div class="inline-block p-4 text-nowrap">
        подробнее
            <i class="fas fa-arrow-right ml-2"></i>
    </div>
</div>
