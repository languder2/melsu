<div
    class="
            bg-black/70
            text-white/90
            rounded-b-lg
            px-4 py-2
            flex
            w-full
            gap-3
            mt-3
        "
>
    {{$slot}}
</div>
