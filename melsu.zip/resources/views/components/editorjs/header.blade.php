<h{{$data->level}}>
    {!! $data->text !!}
</h{{$data->level}}>


