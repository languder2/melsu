<div class="p-4">
    Выбрать менеджеров:

    @dump($managers ?? 'no list')
</div>

