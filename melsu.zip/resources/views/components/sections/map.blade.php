<section class="map-section">
    <div class="map-wrapper container custom p-2.5 xl:p-0">
        <div class="map-card text-lg">
            <h4>
                Карта кампуса МелГУ
            </h4>
            <p>
                Здесь вы можете посмотреть все объекты университетского кампуса
            </p>
            <div class="btn-more-box flex items-center">
                <a href="https://melsu.ru/campus-map" class="btn-more flex items-center">К карте
                <i class="bi bi-arrow-right-circle-fill"></i></a>
            </div>
        </div>
    </div>
</section>
