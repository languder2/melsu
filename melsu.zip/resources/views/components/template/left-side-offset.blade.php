<div class="side_offset">
    <ul class="box-side-social-link">
        <li>
            <a href="https://vk.com/mlt_mgu" class="social-link" target="_blank">
                <i class="fab fa-vk" aria-hidden="true"></i>
            </a>
        </li>
        <li>
            <a href="https://t.me/mgu_mlt" class="social-link" target="_blank">
                <i class="bi bi-telegram"></i>
            </a>
        </li>
        <li>
            <a href="https://rutube.ru/channel/36418660/" class="social-link ps-3" target="_blank">
                <img src="{{ asset('img/ico/Minilogo_RUTUBE_dark_color.png') }}" alt="rutube" class="h-3 inline-block -mt-1 mb-1" >
            </a>
        </li>

    </ul>
    <img
        src="{{asset('img/logo-09.05.webp')}}"
        alt=""
        class="mt-40 hidden"
    />
</div>
