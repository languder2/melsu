<div
    id="tab_documents"
    @class([
        "form_box",
        "bg-amber-700 text-white p-4",
        (old('side_menu') === 'tab_documents')?'':'hidden'
    ])
>
    documents 123
</div>
