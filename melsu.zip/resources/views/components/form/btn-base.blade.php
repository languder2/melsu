<button class="
                bg-blue-900
                px-4 py-2
                text-white
                rounded-md
                hover:bg-blue-700
                active:bg-gray-700
                {{@$class}}
            ">
    {{@$text}}
</button>
