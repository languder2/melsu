@props([
    'list' => collect()
])
