<nav class="bg-white p-4 flex">

    <x-html.a-blue
        href="{{ route('admin:division:list') }}"
        text="Структура подразделений"
    />
</nav>



