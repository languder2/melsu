<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_base'
    text='Базовые параметры'
    :active="true"
/>

<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_contacts'
    text='Контакты'
/>

<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_contents'
    text='Секции контента'
/>

<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_upbringing'
    text='Воспитательная работа (Филиалы)'
/>

<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_partner'
    text='Партнеры'
/>

<x-html.admin.form-menu-item
    tabs='form_box'
    tab='tab_news'
    text='Новости'
/>
