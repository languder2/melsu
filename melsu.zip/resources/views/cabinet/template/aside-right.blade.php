<aside class="right bg-neutral-150 hidden 2xl:block w-96 border-r drop-shadow-md">
    <h3 class="font-semibold p-4 text-right">
        Возможности
    </h3>
    <hr class="border-blue">
    <div class="wrapper absolute inset-0 top-15 overflow-y-scroll flex flex-col gap-4 p-4 ">

        <ul>
            <li class="flex justify-between ">
                <a
                    href="{{ route('ticket:add') }}"
                    class="text-blue hover:text-green-800"
                >
                    Создать тикет
                </a>
                <button>?</button>
            </li>
        </ul>
    </div>
</aside>
