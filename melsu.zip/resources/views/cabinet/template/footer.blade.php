<footer
    class="py-2 text-white bg-cover bg-[image:var(--bg-cabinet-header)] text-center text-sm"
>
    &copy; 2025 ФГБОУ ВО "МелГу"
</footer>
