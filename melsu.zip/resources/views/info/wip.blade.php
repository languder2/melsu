@extends("layouts.info")

@section('title', 'ФГБОУ ВО "МелГУ"')

@section('breadcrumbs')

@endsection

@section('content-header')
    Work in Process
@endsection

@section('content')

    <div
        id="dropZone"
        class="mr-4 p-4 min-h-60 border">

        123
    </div>


@endsection


