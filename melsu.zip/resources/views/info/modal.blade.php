<div id="modal" class="absolute z-50 inset-0 bg-gray-900/40 flex items-center" hidden>
    <div id="modal-wrapper" class="bg-white w-4xl mx-auto rounded">
        <div class="flex gap-4 p-4">
            <div id="modal-header" class="flex-1 text-center">

            </div>
            <a href="javascript:Modal.closeModal()">
                close
            </a>
        </div>
    </div>
</div>
