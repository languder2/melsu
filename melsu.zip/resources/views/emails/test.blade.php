<h3>
 {{$header}}
</h3>
<section>

    {{$user->firstname}}
    {{$user->lastname}}
</section>
