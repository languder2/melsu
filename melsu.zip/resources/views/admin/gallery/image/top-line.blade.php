<div class="bg-white rounded-md p-4 mb-4 flex gap-4 items-center">
    <div class="flex-1">

        filter

    </div>
    <div class="">
        <a href="{{route('admin:image:form')}}" class="
                py-2 px-4
                rounded-md
                text-white
                bg-blue-950 hover:bg-blue-700 active:bg-gray-700
            ">
            <i class="fas fa-plus w-4 py-2"></i>
        </a>
    </div>
</div>

