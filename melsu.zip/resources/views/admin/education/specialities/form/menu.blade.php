<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_speciality'
        text='Специальность'
        :active="true"
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_profile'
        text='Профили'
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_documents'
        text='Документы'
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_contents'
        text='Секции контента'
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_links'
        text='Ссылки'
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_faq'
        text='FAQ'
/>

<x-html.admin.form-menu-item
        tabs='form_box'
        tab='tab_career'
        text='Карьеры'
/>
