// import './bootstrap';
import './info/fileupload.js';

import {FetchGet} from './info/fetch.js';
import {FetchPost} from './info/fetch.js';

import * as Modal from './info/modal.js';
window.Modal = Modal;
